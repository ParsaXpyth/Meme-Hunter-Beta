"""Trade Setup - Flask backend.

Run:  python app.py   ->  http://127.0.0.1:5000
Data: CoinGecko (prices/charts), RSS feeds (news), TradingView widgets (live charts, in the browser).
"""
import math
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from functools import wraps

import requests
from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

try:  # safer XML parsing for third-party feeds
    from defusedxml import ElementTree as ET
except ImportError:  # pragma: no cover
    import xml.etree.ElementTree as ET

BASE = os.path.dirname(os.path.abspath(__file__))
DL_DIR = os.path.join(BASE, "static", "downloads")
APK_NAME = "trade-setup.apk"

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-change-me-in-production"),
    DATABASE=os.path.join(BASE, "tradesetup.db"),
    # DEMO_PAYMENT=1 activates Pro instantly (for development only).
    DEMO_PAYMENT=os.environ.get("DEMO_PAYMENT", "1") == "1",
    COINGECKO_KEY=os.environ.get("COINGECKO_KEY", ""),  # optional free demo key
    SESSION_COOKIE_SAMESITE="Lax",
)

# ---------------------------------------------------------------- data sources
CG = "https://api.coingecko.com/api/v3"
COINS = {  # symbol: (coingecko id, name, TradingView symbol)
    "BTC": ("bitcoin", "Bitcoin", "BINANCE:BTCUSDT"),
    "ETH": ("ethereum", "Ethereum", "BINANCE:ETHUSDT"),
    "SOL": ("solana", "Solana", "BINANCE:SOLUSDT"),
    "BNB": ("binancecoin", "BNB", "BINANCE:BNBUSDT"),
    "XRP": ("ripple", "XRP", "BINANCE:XRPUSDT"),
    "ADA": ("cardano", "Cardano", "BINANCE:ADAUSDT"),
    "DOGE": ("dogecoin", "Dogecoin", "BINANCE:DOGEUSDT"),
    "TON": ("the-open-network", "Toncoin", "BINANCE:TONUSDT"),
    "TRX": ("tron", "TRON", "BINANCE:TRXUSDT"),
    "AVAX": ("avalanche-2", "Avalanche", "BINANCE:AVAXUSDT"),
}
FREE_COINS = ["BTC", "ETH", "SOL", "BNB", "XRP"]

FEEDS = [  # (name, url, pro_only)
    ("Cointelegraph", "https://cointelegraph.com/rss", False),
    ("BBC Business", "https://feeds.bbci.co.uk/news/business/rss.xml", False),
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/", True),
    ("Decrypt", "https://decrypt.co/feed", True),
    ("CNBC Finance", "https://www.cnbc.com/id/10000664/device/rss/rss.html", True),
]

PLANS = {"monthly": {"days": 30, "price": "9.99"}, "yearly": {"days": 365, "price": "79"}}

_cache = {}


def cached(key, ttl, fn):
    """Tiny in-memory TTL cache that falls back to stale data if upstream fails."""
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    try:
        val = fn()
    except Exception:
        if hit:
            return hit[1]
        raise
    _cache[key] = (time.time(), val)
    return val


def cg_headers():
    key = app.config["COINGECKO_KEY"]
    return {"x-cg-demo-api-key": key} if key else {}


def get_markets():
    def go():
        ids = ",".join(v[0] for v in COINS.values())
        r = requests.get(
            f"{CG}/coins/markets",
            params={"vs_currency": "usd", "ids": ids, "sparkline": "true",
                    "price_change_percentage": "24h"},
            headers=cg_headers(), timeout=10)
        r.raise_for_status()
        by_id = {c["id"]: c for c in r.json()}
        out = {}
        for sym, (cid, name, tv) in COINS.items():
            c = by_id.get(cid)
            if not c:
                continue
            spark = (c.get("sparkline_in_7d") or {}).get("price") or []
            out[sym] = dict(symbol=sym, name=name, tv=tv, price=c["current_price"],
                            change24h=c.get("price_change_percentage_24h") or 0,
                            spark=spark[::6])
        return out
    return cached("markets", 60, go)


def parse_feed(name, url):
    r = requests.get(url, headers={"User-Agent": "TradeSetup/1.0"}, timeout=10)
    r.raise_for_status()
    root = ET.fromstring(r.content)
    items = []
    for it in root.iter("item"):
        title = (it.findtext("title") or "").strip()
        link = (it.findtext("link") or "").strip()
        if not title or not link.startswith("http"):
            continue
        try:
            ts = parsedate_to_datetime(it.findtext("pubDate")).timestamp()
        except Exception:
            ts = 0
        desc = re.sub(r"<[^>]+>", "", it.findtext("description") or "").strip()
        items.append(dict(source=name, title=title, link=link, ts=ts, summary=desc[:200]))
    return items[:15]


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  pw TEXT NOT NULL,
  pro_until TEXT
);
CREATE TABLE IF NOT EXISTS holdings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  symbol TEXT NOT NULL,
  amount REAL NOT NULL,
  buy_price REAL NOT NULL
);
"""


def init_db():
    with sqlite3.connect(app.config["DATABASE"]) as c:
        c.executescript(SCHEMA)


def db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    d = g.pop("db", None)
    if d:
        d.close()


# ---------------------------------------------------------------- auth helpers
def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    return db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def is_pro(u):
    if not u or not u["pro_until"]:
        return False
    return datetime.fromisoformat(u["pro_until"]) > datetime.now(timezone.utc)


def activate_pro(uid, days):
    row = db().execute("SELECT pro_until FROM users WHERE id=?", (uid,)).fetchone()
    start = datetime.now(timezone.utc)
    if row and row["pro_until"]:
        start = max(start, datetime.fromisoformat(row["pro_until"]))
    db().execute("UPDATE users SET pro_until=? WHERE id=?",
                 ((start + timedelta(days=days)).isoformat(), uid))
    db().commit()


def _deny(code, page_endpoint):
    if request.path.startswith("/api/"):
        return jsonify(error=code), (401 if code == "login_required" else 402)
    if code == "login_required":
        return redirect(url_for("login", next=request.path))
    return redirect(url_for(page_endpoint))


def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not current_user():
            return _deny("login_required", "login")
        return f(*a, **k)
    return w


def pro_required(f):
    @wraps(f)
    def w(*a, **k):
        u = current_user()
        if not u:
            return _deny("login_required", "login")
        if not is_pro(u):
            return _deny("pro_required", "pricing")
        return f(*a, **k)
    return w


@app.before_request
def csrf_protect():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method in ("POST", "PUT", "DELETE"):
        token = request.headers.get("X-CSRF") or request.form.get("csrf") or ""
        if not secrets.compare_digest(token, session["csrf"]):
            abort(400)


@app.context_processor
def inject():
    u = current_user()
    return dict(user=u, pro=is_pro(u), csrf=session.get("csrf", ""),
                has_apk=os.path.exists(os.path.join(DL_DIR, APK_NAME)))


def safe_next(url):
    return url if url and url.startswith("/") and not url.startswith("//") else url_for("index")


# ---------------------------------------------------------------- pages
@app.get("/")
def index():
    syms = list(COINS)
    return render_template("dashboard.html", coins=[(s, COINS[s][2]) for s in syms])


@app.get("/calculator")
def calculator():
    return render_template("calculator.html")


@app.get("/news")
def news_page():
    return render_template("news.html")


@app.get("/portfolio")
@pro_required
def portfolio():
    return render_template("portfolio.html", coins=list(COINS))


@app.get("/pricing")
def pricing():
    return render_template("pricing.html", plans=PLANS)


@app.get("/download")
def download():
    return render_template("download.html")


@app.get("/download/apk")
def download_apk():
    if not os.path.exists(os.path.join(DL_DIR, APK_NAME)):
        abort(404)
    return send_from_directory(DL_DIR, APK_NAME, as_attachment=True,
                               mimetype="application/vnd.android.package-archive")


@app.get("/sw.js")
def service_worker():
    return send_from_directory(app.static_folder, "sw.js", mimetype="application/javascript")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        if not name or "@" not in email or len(pw) < 8:
            flash("نام، ایمیل معتبر و رمز عبور حداقل ۸ کاراکتری وارد کنید.")
        else:
            try:
                cur = db().execute("INSERT INTO users(email,name,pw) VALUES(?,?,?)",
                                   (email, name, generate_password_hash(pw)))
                db().commit()
                session["uid"] = cur.lastrowid
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                flash("با این ایمیل قبلاً ثبت‌نام شده است. وارد شوید.")
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        row = db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if row and check_password_hash(row["pw"], request.form.get("password", "")):
            session["uid"] = row["id"]
            return redirect(safe_next(request.args.get("next")))
        flash("ایمیل یا رمز عبور درست نیست.")
    return render_template("auth.html", mode="login")


@app.post("/logout")
def logout():
    session.pop("uid", None)
    return redirect(url_for("index"))


@app.post("/subscribe/<plan>")
@login_required
def subscribe(plan):
    if plan not in PLANS:
        abort(404)
    if app.config["DEMO_PAYMENT"]:
        activate_pro(session["uid"], PLANS[plan]["days"])
        flash("اشتراک Pro فعال شد (حالت آزمایشی).")
        return redirect(url_for("index"))
    # Production: create a checkout session with Stripe / ZarinPal / etc. here,
    # redirect the user to it, then call activate_pro() from the verified
    # payment webhook/callback - never from the browser.
    abort(501, "Payment gateway is not configured.")


# ---------------------------------------------------------------- market API
@app.get("/api/prices")
def api_prices():
    try:
        data = get_markets()
    except Exception:
        return jsonify(error="upstream_unavailable"), 502
    syms = list(COINS) if is_pro(current_user()) else FREE_COINS
    return jsonify([data[s] for s in syms if s in data])


@app.get("/api/chart/<symbol>")
def api_chart(symbol):
    symbol = symbol.upper()
    if symbol not in COINS:
        abort(404)
    days = min(max(request.args.get("days", 7, type=int), 1), 365)
    if days > 30 and not is_pro(current_user()):
        return jsonify(error="pro_required"), 402

    def go():
        r = requests.get(f"{CG}/coins/{COINS[symbol][0]}/market_chart",
                         params={"vs_currency": "usd", "days": days},
                         headers=cg_headers(), timeout=10)
        r.raise_for_status()
        return [[int(t), p] for t, p in r.json()["prices"]]
    try:
        return jsonify(symbol=symbol, days=days, prices=cached(f"chart:{symbol}:{days}", 300, go))
    except Exception:
        return jsonify(error="upstream_unavailable"), 502


@app.get("/api/news")
def api_news():
    pro = is_pro(current_user())
    items = []
    for name, url, pro_only in FEEDS:
        if pro_only and not pro:
            continue
        try:
            items += cached(f"feed:{name}", 300, lambda n=name, u=url: parse_feed(n, u))
        except Exception:
            continue
    if not items:
        return jsonify(error="upstream_unavailable"), 502
    items.sort(key=lambda x: x["ts"], reverse=True)
    cap = 40 if pro else 12
    limit = min(request.args.get("limit", cap, type=int), cap)
    return jsonify(items=items[:limit], pro=pro)


# ---------------------------------------------------------------- calculators
def num(d, key, allow_zero=False):
    try:
        v = float(d.get(key))
    except (TypeError, ValueError):
        raise ValueError(key)
    if not math.isfinite(v) or v < 0 or (v == 0 and not allow_zero):
        raise ValueError(key)
    return v


@app.post("/api/calc/trade")
def calc_trade():
    d = request.get_json(silent=True) or {}
    try:
        side = d.get("side", "long")
        if side not in ("long", "short"):
            raise ValueError("side")
        capital, lev = num(d, "capital"), num(d, "leverage")
        entry, exit_ = num(d, "entry"), num(d, "exit")
        fee = num(d, "fee", allow_zero=True)
    except ValueError as e:
        return jsonify(error=f"invalid:{e}"), 400
    sign = 1 if side == "long" else -1
    size = capital * lev
    qty = size / entry
    gross = (exit_ - entry) * qty * sign
    fees = (size + exit_ * qty) * fee / 100
    pnl = gross - fees
    liquidated = lev > 1 and pnl <= -capital
    if liquidated:
        pnl = -capital
    liq = None
    if lev > 1:
        liq = entry * (1 - 1 / lev) if side == "long" else entry * (1 + 1 / lev)
    return jsonify(size=size, qty=qty, gross=gross, fees=fees, pnl=pnl,
                   roi=pnl / capital * 100, balance=capital + pnl,
                   liquidation=liq, liquidated=liquidated,
                   break_even=entry * (1 + sign * 2 * fee / 100))


@app.post("/api/calc/risk")
@pro_required
def calc_risk():
    d = request.get_json(silent=True) or {}
    try:
        side = d.get("side", "long")
        if side not in ("long", "short"):
            raise ValueError("side")
        balance, risk = num(d, "balance"), num(d, "risk")
        entry, stop, tp = num(d, "entry"), num(d, "stop"), num(d, "tp")
        fee = num(d, "fee", allow_zero=True)
        if risk > 100:
            raise ValueError("risk")
        ok = stop < entry < tp if side == "long" else tp < entry < stop
        if not ok:
            raise ValueError("levels")
    except ValueError as e:
        return jsonify(error=f"invalid:{e}"), 400
    risk_amt = balance * risk / 100
    qty = risk_amt / abs(entry - stop)
    value = qty * entry
    reward = abs(tp - entry) * qty
    fees = (value + qty * tp) * fee / 100
    rr = reward / risk_amt
    return jsonify(risk_amount=risk_amt, qty=qty, position_value=value,
                   reward=reward, rr=rr, fees=fees, net_reward=reward - fees,
                   min_leverage=value / balance, win_rate_needed=100 / (1 + rr))


# ---------------------------------------------------------------- Pro: portfolio
@app.get("/api/pro/portfolio")
@pro_required
def api_portfolio():
    rows = db().execute("SELECT * FROM holdings WHERE user_id=? ORDER BY id DESC",
                        (session["uid"],)).fetchall()
    try:
        m = get_markets()
    except Exception:
        return jsonify(error="upstream_unavailable"), 502
    out, value, cost = [], 0.0, 0.0
    for r in rows:
        price = m.get(r["symbol"], {}).get("price", 0)
        v, c = price * r["amount"], r["buy_price"] * r["amount"]
        value += v
        cost += c
        out.append(dict(id=r["id"], symbol=r["symbol"], amount=r["amount"],
                        buy_price=r["buy_price"], price=price, value=v, pnl=v - c,
                        pnl_pct=(v - c) / c * 100 if c else 0))
    pnl = value - cost
    return jsonify(holdings=out, totals=dict(value=value, cost=cost, pnl=pnl,
                                             pnl_pct=pnl / cost * 100 if cost else 0))


@app.post("/api/pro/portfolio")
@pro_required
def api_portfolio_add():
    d = request.get_json(silent=True) or {}
    try:
        sym = str(d.get("symbol", "")).upper()
        if sym not in COINS:
            raise ValueError("symbol")
        amount, price = num(d, "amount"), num(d, "buy_price")
    except ValueError as e:
        return jsonify(error=f"invalid:{e}"), 400
    n = db().execute("SELECT COUNT(*) FROM holdings WHERE user_id=?", (session["uid"],)).fetchone()[0]
    if n >= 100:
        return jsonify(error="invalid:limit"), 400
    db().execute("INSERT INTO holdings(user_id,symbol,amount,buy_price) VALUES(?,?,?,?)",
                 (session["uid"], sym, amount, price))
    db().commit()
    return jsonify(ok=True), 201


@app.delete("/api/pro/portfolio/<int:hid>")
@pro_required
def api_portfolio_delete(hid):
    db().execute("DELETE FROM holdings WHERE id=? AND user_id=?", (hid, session["uid"]))
    db().commit()
    return jsonify(ok=True)


@app.get("/api/app-version")
def app_version():
    return jsonify(version="1.0", apk=url_for("download_apk", _external=True))


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
