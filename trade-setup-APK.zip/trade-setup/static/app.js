// Trade Setup - front-end logic (no build step needed)
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const CSRF = $('meta[name=csrf]').content;
const fmt = (n, d = 2) => Number(n).toLocaleString('en-US', { maximumFractionDigits: d });
const money = n => '$' + fmt(n, Math.abs(n) < 1 ? 4 : 2);
const signed = (n, suffix = '') => (n > 0 ? '+' : '') + fmt(n) + suffix;

function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) k === 'class' ? (e.className = v) : e.setAttribute(k, v);
  kids.flat().forEach(k => e.append(k));
  return e;
}

async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', 'X-CSRF': CSRF, ...(opts.headers || {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'error'), { status: res.status });
  return data;
}

function errorText(e, form) {
  if (e.status === 401) return 'برای استفاده از این بخش وارد حساب خود شوید.';
  if (e.status === 402) return 'این قابلیت مخصوص کاربران Pro است.';
  if (e.message === 'invalid:levels') return 'حد ضرر و حد سود باید در سمت درست قیمت ورود باشند (در خرید: حد ضرر پایین‌تر و حد سود بالاتر).';
  if (e.message.startsWith('invalid:')) {
    const f = e.message.slice(8), lab = form?.elements[f]?.closest('label')?.querySelector('span');
    return `مقدار «${lab ? lab.textContent : f}» درست نیست. یک عدد بزرگ‌تر از صفر وارد کنید.`;
  }
  if (e.message === 'upstream_unavailable') return 'اتصال به منبع داده برقرار نشد. چند لحظه بعد دوباره امتحان کنید.';
  return 'خطایی رخ داد. دوباره تلاش کنید.';
}

/* ---------- prices: ticker + market list ---------- */
function spark(points, up) {
  if (!points.length) return '';
  const w = 90, h = 28, min = Math.min(...points), max = Math.max(...points), rng = max - min || 1;
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${(i / (points.length - 1) * w).toFixed(1)},${(h - (p - min) / rng * h).toFixed(1)}`).join('');
  return `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" aria-hidden="true"><path d="${d}" fill="none" stroke="${up ? 'var(--up)' : 'var(--down)'}" stroke-width="1.6"/></svg>`;
}

async function loadPrices() {
  let coins;
  try { coins = await api('/api/prices'); } catch (e) { $('#market-list') && ($('#market-list').textContent = errorText(e)); return; }
  const ticker = $('#ticker');
  if (ticker) ticker.innerHTML = coins.map(c =>
    `<span><b>${c.symbol}</b><span class="num">${money(c.price)}</span><span class="num ${c.change24h >= 0 ? 'up' : 'down'}">${signed(c.change24h, '%')}</span></span>`).join('');
  const list = $('#market-list');
  if (list) list.innerHTML = coins.map(c => `
    <div class="coin"><div><b>${c.name}</b><small>${c.symbol}</small></div>
    <div>${spark(c.spark, c.change24h >= 0)}</div>
    <div class="p"><div>${money(c.price)}</div><small class="${c.change24h >= 0 ? 'up' : 'down'}">${signed(c.change24h, '%')}</small></div></div>`).join('');
}

/* ---------- news ---------- */
async function loadNews(box) {
  box.textContent = 'در حال بارگذاری…';
  try {
    const { items } = await api('/api/news?limit=' + (box.dataset.limit || 10));
    box.replaceChildren(...items.map(n => el('a', { href: n.link, target: '_blank', rel: 'noopener noreferrer' },
      el('b', {}, n.title),
      el('small', {}, `${n.source} · ${n.ts ? new Date(n.ts * 1000).toLocaleString('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }) : ''}`))));
  } catch (e) { box.textContent = errorText(e); }
}

/* ---------- TradingView chart ---------- */
function initChart() {
  const box = $('#tv_chart'), sel = $('#chart-symbol');
  if (!box) return;
  const draw = () => {
    if (!window.TradingView) { box.textContent = 'بارگذاری چارت TradingView ممکن نشد. اتصال اینترنت را بررسی کنید.'; return; }
    box.replaceChildren();
    new TradingView.widget({
      container_id: 'tv_chart', autosize: true, symbol: sel.value, interval: '60', timezone: 'Etc/UTC',
      theme: 'dark', style: '1', locale: 'en', backgroundColor: '#1b1830', gridColor: '#272340',
      allow_symbol_change: false, hide_side_toolbar: false, withdateranges: true,
    });
  };
  sel.addEventListener('change', draw);
  draw();
}

/* ---------- calculators ---------- */
const row = (k, v, cls = '') => el('div', {}, el('span', {}, k), el('b', { class: 'num ' + cls }, v));
const RENDER = {
  trade: r => [
    row('حجم پوزیشن', money(r.size)), row('تعداد واحد', fmt(r.qty, 6)),
    row('سود/زیان ناخالص', money(r.gross), r.gross >= 0 ? 'up' : 'down'), row('کارمزد کل', money(r.fees)),
    row('سود/زیان خالص', money(r.pnl), r.pnl >= 0 ? 'up' : 'down'),
    row('بازده روی سرمایه', signed(r.roi, '%'), r.roi >= 0 ? 'up' : 'down'),
    row('سرمایه نهایی', money(r.balance)), row('نقطه سر‌به‌سر', money(r.break_even)),
    ...(r.liquidation ? [row('قیمت تقریبی لیکوئید', money(r.liquidation), 'down')] : []),
    ...(r.liquidated ? [el('div', { class: 'msg' }, 'با این قیمت خروج، کل سرمایه از دست می‌رود.')] : []),
  ],
  risk: r => [
    row('مبلغ در معرض ریسک', money(r.risk_amount)), row('تعداد واحد', fmt(r.qty, 6)),
    row('ارزش پوزیشن', money(r.position_value)), row('حداقل اهرم لازم', fmt(r.min_leverage) + 'x'),
    row('سود احتمالی', money(r.reward), 'up'), row('کارمزد کل', money(r.fees)),
    row('نسبت سود به ریسک', '1 : ' + fmt(r.rr)), row('حداقل نرخ برد برای سر‌به‌سر', fmt(r.win_rate_needed, 1) + '%'),
  ],
};

function initCalc() {
  $$('form[data-calc]').forEach(form => form.addEventListener('submit', async ev => {
    ev.preventDefault();
    const kind = form.dataset.calc, out = $(`[data-result=${kind}]`);
    const body = Object.fromEntries(new FormData(form));
    try {
      const r = await api('/api/calc/' + kind, { method: 'POST', body: JSON.stringify(body) });
      out.replaceChildren(...RENDER[kind](r));
    } catch (e) { out.replaceChildren(el('div', { class: 'msg', role: 'alert' }, errorText(e, form))); }
  }));
}

/* ---------- portfolio (Pro) ---------- */
async function loadPortfolio() {
  const full = !!$('#pf-table');
  try {
    const { holdings, totals } = await api('/api/pro/portfolio');
    const cls = totals.pnl >= 0 ? 'up' : 'down';
    $('#pf-value').textContent = money(totals.value);
    const pnl = $('#pf-pnl');
    pnl.textContent = `${money(totals.pnl)} (${signed(totals.pnl_pct, '%')})`;
    pnl.className = 'num ' + (full ? 'big ' : '') + cls;
    if (!full) return;
    $('#pf-cost').textContent = money(totals.cost);
    $('#pf-empty').hidden = holdings.length > 0;
    $('#pf-table tbody').replaceChildren(...holdings.map(h => {
      const c = h.pnl >= 0 ? 'up' : 'down';
      const del = el('button', { class: 'btn ghost', 'aria-label': 'حذف ' + h.symbol }, 'حذف');
      del.onclick = async () => { await api('/api/pro/portfolio/' + h.id, { method: 'DELETE' }); loadPortfolio(); };
      return el('tr', {}, el('td', {}, h.symbol), el('td', { class: 'num' }, fmt(h.amount, 8)), el('td', { class: 'num' }, money(h.buy_price)),
        el('td', { class: 'num' }, money(h.price)), el('td', { class: 'num' }, money(h.value)),
        el('td', { class: `num ${c}` }, `${money(h.pnl)} (${signed(h.pnl_pct, '%')})`), el('td', {}, del));
    }));
  } catch (e) { const t = $('#pf-err'); if (t) t.textContent = errorText(e); }
}

function initPortfolio() {
  const form = $('#pf-form');
  if (form) form.addEventListener('submit', async ev => {
    ev.preventDefault();
    $('#pf-err').textContent = '';
    try {
      await api('/api/pro/portfolio', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
      form.reset(); loadPortfolio();
    } catch (e) { $('#pf-err').textContent = errorText(e, form); }
  });
  if ($('#pf-value')) loadPortfolio();
}

/* ---------- boot ---------- */
loadPrices(); setInterval(loadPrices, 60000);
$$('#news-list').forEach(loadNews);
initChart(); initCalc(); initPortfolio();
if ($('#pf-value')) setInterval(loadPortfolio, 60000);
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
