# Trade Setup

سایت واسطه برای محاسبه سود و زیان معاملات، مدیریت ریسک، پورتفوی و اخبار بازار. نوشته‌شده با Python (Flask)، قابل اجرا در VS Code، همراه با اپ اندروید.

## اجرا در VS Code

1. پوشه `trade-setup` را در VS Code باز کنید (File > Open Folder).
2. ترمینال VS Code را باز کنید (Ctrl+`) و اجرا کنید:

```bash
python -m venv .venv
# ویندوز:   .venv\Scripts\activate
# مک/لینوکس: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

3. آدرس http://127.0.0.1:5000 را باز کنید. (در VS Code افزونه Python را نصب و `.venv` را به‌عنوان interpreter انتخاب کنید.)

## منابع داده

| بخش | منبع |
|---|---|
| چارت زنده | ویجت رسمی TradingView (TradingView API عمومی برای داده ندارد؛ ویجت‌ها راه رسمی نمایش چارت هستند) |
| قیمت و تاریخچه | CoinGecko (رایگان؛ برای ترافیک بالا کلید بگیرید و `COINGECKO_KEY` را تنظیم کنید) |
| اخبار | RSS از Cointelegraph، BBC Business (رایگان) و CoinDesk، Decrypt، CNBC (Pro) |

API داخلی: `/api/prices`، `/api/chart/<BTC>`، `/api/news`، `/api/calc/trade`، `/api/calc/risk` (Pro)، `/api/pro/portfolio` (Pro).

## بخش Pro

رایگان: ۵ ارز، ماشین‌حساب سود و زیان، ۱۲ خبر از ۲ منبع.
Pro: ۱۰ ارز، تاریخچه تا ۱ سال، مدیریت ریسک و حجم معامله، پورتفوی، ۴۰ خبر از ۵ منبع.

به‌صورت پیش‌فرض `DEMO_PAYMENT=1` است و خرید اشتراک بدون پرداخت واقعی فعال می‌شود (فقط برای توسعه).
برای انتشار واقعی:
1. `export DEMO_PAYMENT=0` و `export SECRET_KEY=<یک رشته تصادفی بلند>`
2. در تابع `subscribe` در `app.py` درگاه پرداخت (Stripe، زرین‌پال و ...) را وصل کنید و `activate_pro()` را فقط از callback/webhook تأییدشده صدا بزنید.
3. قیمت‌ها در `PLANS` داخل `app.py` قابل تغییر هستند.
4. برای انتشار از gunicorn/waitress پشت HTTPS استفاده کنید (نه `debug=True`).

## اپ اندروید

پوشه `android/` یک پروژه Android Studio است که سایت را داخل یک اپ بومی (WebView) با همان حساب و همان قابلیت‌ها نشان می‌دهد.

1. Android Studio را باز کنید و پوشه `android` را Open کنید.
2. در `app/build.gradle` آدرس `SITE_URL` را تنظیم کنید (برای گوشی واقعی روی همان Wi-Fi: `http://IP-کامپیوتر:5000` و برای نسخه نهایی: دامنه HTTPS شما).
3. Build > Build APK(s) را بزنید (برای نسخه عمومی: Build > Generate Signed App Bundle / APK).
4. فایل APK را با نام `trade-setup.apk` در `static/downloads/` بگذارید. صفحه `/download` سایت به‌طور خودکار دکمه دانلود را نشان می‌دهد.

همچنین سایت PWA است و از منوی Chrome گوشی با «Add to Home screen» نصب می‌شود.
